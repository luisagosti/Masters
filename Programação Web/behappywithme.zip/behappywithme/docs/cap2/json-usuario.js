let usuario = {
    "login": "fulano",
    "nome": "Fulano",
    "sobrenome": "Ciclano",
    "endereco": "Rua 123",
    "idade": "20"
};