React.createElement(
    'div',
    null,
    React.createElement(
        'h1',
        null,
        'Um título qualquer'
    ),
    React.createElement(
        'span',
        null,
        'Um texto'
    )
);